##Question 3
(a) `chmod 740 fpga`
(b) `wget http://www.fpga.com/bitstream.gz`
(c) `tar -zxvf bitstream.gz`
(d) `lsof -u jack -u dave`
(e) `grep -r "fpga" -l`